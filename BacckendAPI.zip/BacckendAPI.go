package main

import (
	"encoding/json"
	"fmt"
	"net/http"
)

type User struct {
	ID          string `json:"id"`
	FirstName   string `json:"first_name"`
	LastName    string `json:"last_name"`
	DateOfBirth string `json:"date_of_birth,omitempty"`
	Email       string `json:"email"`
	PhoneNumber string `json:"phone_number"`
}

var users []User

func main() {
	http.HandleFunc("/users", handleCreateUser)
	http.HandleFunc("/users/", handleGetUser)
	http.HandleFunc("/users/all", handleGetAllUsers)
	http.HandleFunc("/users/edit", handleEditUser)

	fmt.Println("Server listening on port 8080")
	if err := http.ListenAndServe(":8080", nil); err != nil {
		fmt.Printf("Server error: %s\n", err)
	}
}

func checkError(err error, w http.ResponseWriter, errMsg string, statusCode int) bool {
	if err != nil {
		http.Error(w, errMsg, statusCode)
		return true
	}
	return false
}

func handleCreateUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var newUser User
	err := json.NewDecoder(r.Body).Decode(&newUser)
	if checkError(err, w, "Invalid request body", http.StatusBadRequest) {
		return
	}

	if err := validateUser(newUser); checkError(err, w, err.Error(), http.StatusBadRequest) {
		return
	}

	users = append(users, newUser)
	w.WriteHeader(http.StatusCreated)
}

func handleGetUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	userID := r.URL.Path[len("/users/"):]
	for _, user := range users {
		if user.ID == userID {
			json.NewEncoder(w).Encode(user)
			return
		}
	}
	http.Error(w, "User not found", http.StatusNotFound)
}

func handleGetAllUsers(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	json.NewEncoder(w).Encode(users)
}

func handleEditUser(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPut {
		http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		return
	}

	var updatedUser User
	err := json.NewDecoder(r.Body).Decode(&updatedUser)
	if checkError(err, w, "Invalid request body", http.StatusBadRequest) {
		return
	}

	if err := validateUser(updatedUser); checkError(err, w, err.Error(), http.StatusBadRequest) {
		return
	}

	for i, user := range users {
		if user.ID == updatedUser.ID {
			users[i] = updatedUser
			w.WriteHeader(http.StatusOK)
			return
		}
	}

	http.Error(w, "User not found", http.StatusNotFound)
}

func validateUser(user User) error {
	if user.ID == "" {
		return fmt.Errorf("ID is required")
	}
	if user.FirstName == "" {
		return fmt.Errorf("First name is required")
	}
	if user.LastName == "" {
		return fmt.Errorf("Last name is required")
	}
	if user.Email == "" {
		return fmt.Errorf("Email is required")
	}
	if user.PhoneNumber == "" {
		return fmt.Errorf("Phone number is required")
	}
	return nil
}
